# Introduction:
  This Folder contains the Traffic Generation.
  The goal of this exercise is to introduce the user to Nping
 
## Website:
  If you encounter problems,questions, or suggestions, please navigate to the
  FABRIC Knowledge Base at https://learn.fabric-testbed.net/

## GIT:
  Before you start make sure you have the latest version of the exercise, you
  can download the latest version of these assignments out of the git server
  by running the following command:

    git clone https://github.com/fabric-testbed/teaching-materials.git

  (This will update all of the assignments so make sure you are in the correct
  directory)

## Content:
  This Exercise contains three notebooks:
  + CreateSlice.ipyb
  + TrafficGeneration.ipyb
  + Assignment.ipyb
 
  This exercise contains one folder
  + scripts
 
  The folder "scripts" contains two scripts made to retain a graph of the trough
  output at a given time in seconds.
 
## Instructions:
   The following are instructions, procedures and notes that are performed during
   the exercise:

### Create Slice:
  In this notebook you will request a slice that contains two nodes, and
  one l2 network with the following configurations: (ln == Lan)

	ND1 <-> ln <-> ND2

  Each node should have the following requirements:
  + NIC_Basic model
  + "default_ubuntu_20" image
  +  4 cores
  + 16 ram
  + 50 disk space
   
  To successfully run this notebook you should only need to run the code blocks
  in order from top to bottom then navigate to the next notebook
 
  **Notes:**
  + If your slice creation fails you can just try to specify a site in the second code block and run them again. (you can get a site from "https://portal.fabric-testbed.net/" by looking at the map, use the name **outside** of the parenthesis and make sure the site chosen is up)
  + if you choose to rename the nodes avoid one character names as they will result in an error on the slice


### Traffic Generation:  
  To successfully run this notebook you need to run the code blocks first (section 1)
  and then run the experiment section (2)
 
  #### Section 1:
  This is the setup, run the provided code blocks to setup the network and to provide
  the correct addresses to each node, the tools for this experiment, and installing the
  script to create the graphs.
 
  #### Section 2:
  This is the Experiment, To complete this section just follow the provided instructions
  to get familiarized with the Nping.
 
  **Notes:**
   + if you run out of memory during the assignment be sure to re-try the assignment increasing the disk space by 50 - 100, if the problem persist lower the time the ss program is running.
   + Do not run iperf with the graphing script for more than 2 minutes to avoid memory errors
 
### Assignment:
  In this Assignment the user will explore what are possible uses for traffic
  generation, and will take a look at how traffic generation is processed
  by looking at the throughput
 
  Lastly you will delete the slice to clear resources you used.
 
  **Notes:**
  + In the case the slice fails to delete please examine the experiment tab on the fabric portal and delete the corresponding slice if it was not already deleted
