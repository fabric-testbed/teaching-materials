# Introduction:
  This Folder contains the Ping  Exercise.
  The goal of this exercise is to understand how a ping implementation could be
  implemented
 
## Website:
  If you encounter problems,questions, or suggestions, please navigate to the
  FABRIC Knowledge Base at https://learn.fabric-testbed.net/

## GIT:
  Before you start make sure you have the latest version of the exercise, you
  can download the latest version of these assignments out of the git server
  by running the following command:

	git clone https://github.com/fabric-testbed/teaching-materials.git

  (This will update all of the assignments so make sure you are in the correct
  directory)

## Content:
  This Exercise contains three notebooks:
  + CreateSlice.ipyb
  + ping.ipyb
 
  This exercise contains one folder
  + scripts
 
  The folder "scripts" contains one script to set up IPv4 site accessibility since we will
  need to access  github to download a program for this exercise
 
## Instructions:
   The following are instructions, procedures and notes that are performed during
   the exercise:

### Create Slice:
  In this notebook you will request a slice that contains two nodes, and
  one l2 network with the following configurations: (ln == Lan)

	client <-> ln <-> server

  Each node should have the following requirements:
  + NIC_Basic model
  + "default_ubuntu_20" image
  + 4 cores
  + 16 ram
  + 50 disk space
   
  To successfully run this notebook you should only need to run the code blocks
  in order from top to bottom then navigate to the next notebook
 
  **Notes:**
  + If your slice creation fails you can just try to specify a site in the second code block run them again. (you can get a site from "https://portal.fabric-testbed.net/" by looking at the map, use the name **outside** of the parenthesis and make sure the site chosen is up)
  + if you choose to rename the nodes avoid one character names as they will result in an error on the slice

### Ping:  
  To successfully run this notebook you need to run the code blocks first (section 1)
  and then run the experiment section (2)
 
  #### Section 1:
  This is the setup, run the provided code blocks to setup the network and to provide
  the correct addresses to each node, and installing the pingplus program for the second
  part of the assignment.
 
  #### Section 2:
  This is the Experiment, To complete this section just follow the provided instructions,
  this  exercise is separated in two parts, the first is a quick introduction to ping and iperf
  the second is an overview of how a ping would happen between two ports, and a quick assignment.
 
  After you have completed the assignment please delete the slice at the last code block.
 
  **Notes**
  + The last cell is to delete the slice and free resources, make sure you set "Check" to "True" to delete the slice
  + In the case the slice fails to delete please examine the experiment tab on the fabric portal and delete the corresponding slice if it was not already deleted

